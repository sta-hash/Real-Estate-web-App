import React from 'react'
import "./Companies.css"
export default function Companies() {
  return (
    <section className ="c-wrapper">
        <div className ="paddings innerWidth flexCenter c-container">
            <img src ="./download.png" alt=""/>
            <img src ="./prologis.png" alt=""/>
            <img src ="./realty.png" alt=""/>
            <img src ="./tower.jpeg" alt=""/>

        </div>
        </section>
  )
}
