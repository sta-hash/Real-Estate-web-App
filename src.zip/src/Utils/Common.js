export const sliderSettings={
    sliderPerView:1,
    spaceBetween:50, 
    breakpionts:{
        480:{
            slidePerView:1,

        },
        600:{
            slidePerView:2,
        },
        750:{
            slidePerView:3,
        },
        1200:{
            slidePerView:4,
        },

    }
}